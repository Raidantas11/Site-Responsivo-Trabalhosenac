$(document).ready(function() {
    $('#search-input').on('input', function() {
        let query = $(this).val().toLowerCase();
        $('.product-item').each(function() {
            let itemText = $(this).text().toLowerCase();
            $(this).toggle(itemText.indexOf(query) !== -1);
        });
    });
});